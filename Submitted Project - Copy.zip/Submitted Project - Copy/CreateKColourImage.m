%To create a k-colour image for an image that has had its pixels divided
%into k clusters.  All pixels in a given cluster will be recoloured using
%the mean colour values for that cluster.

%Inputs: 1.) A 2D array with values specifiying the cluster each pixel
%            belongs to
%        2.) The mean array that has been outputted from KMeansRGB after
%            convergence of the means

%Outputs: 1.) A 3D array of unsigned 8 bit integers with each pixel having
%             its colour assoociated with its corresponding cluster's mean
%             RGB colour values


function MyImage = CreateKColourImage(clusters,means)

round(means) %means need to be integers to be displayed in uint8 format

clusters(:,:,2:3) = 0; %initialises/creates the values of layers 2 and 3 to
                       %store the green and blue colour values


[rows,cols,layers] = size(clusters); 

for i = 1:rows
    for j = 1:cols
        for m = 1:length(means)
            
            %cycling through clusters array. If the cluster number (in
            %layer 1) equals the cluster number m, the i,j and k value of
            %the pixel will get changed to its corresponding cluster's mean
            %RGB colour value
            if clusters(i,j,1) == m
                clusters(i,j,:) = means(m,1,:);
            end
            
        end
    end
end

MyImage = uint8(clusters);



end
%ONLY SHOWS PICTURE IN RED