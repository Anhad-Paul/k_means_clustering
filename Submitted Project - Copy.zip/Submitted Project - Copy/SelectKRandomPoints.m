%Generates a list of k randomly selected pixels from an image

%Inputs: 1. A 3D image array
%        2. Number of points to randomly select

%Outputs: 1. A 2D array containing k rows and 2 columns representing k
%           randomly selected points. Column 1 stores the row the random
%           point is in, Column 2 stores column the random point is in.

%Author: Anhad Paul


function [points] = SelectKRandomPoints(imageArray,NumOfMeans)

    [rows,columns,colours] = size(imageArray);
    points = zeros(NumOfMeans,2);

    %Creates initial array which may OR may not have duplicate points (rows) in
    %it
    %numOfmeans corresponds with amount of rows
    %An element in row 1 must be a random row number
    %An element in row 2 must be a random column number
    for i = 1:NumOfMeans
        points(i,1) = randi(rows,1);
        points(i,2) = randi(columns,1);  
    end

    %IF 2 duplicate rows are found, the unique function will delete the,
    %giving r a different length to points
    r = unique(points,'rows');

    %IF a duplicate row has been found and eliminated, we must cycle
    %through the array and compare each and every row against the original
    %array 'points'.
    while length(r) ~= length(points)

        for j = 1:NumOfMeans

            %The find function will cycle through the array and find where
            %the particular sub-array points(j,:) occurs in the array 'points'
            cmp = find(points == points(j,:));

            %if the sub-array is found only once, it is unique and will
            %give cmp a length of only 2 (1 for the row + 1 for the column)
            %A length of greater than 2 means the point is not unique and
            %must be replaced by a new random point
            if length(cmp) ~= 2
                points(j,1) = randi(rows,1);
                points(j,2) = randi(columns,1);
            end

           %uses the unique function again to eliminate any duplicates that
           %still might be present even after cycling through the array. If
           %no extra duplicates were found, r=points and we can exit the while
           %loop. IF there are still duplicates, they will be eliminated
           %and will yet again change the length of r causing the code to
           %go through the while loop again
           r = unique(points,'rows');

        end
    end
end