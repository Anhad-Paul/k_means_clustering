% This script converts an image containing many colours
% into one containing just k colours (where k is a small number)
% It does this using by using the k-means algorithm, a general purpose
% data science algorithm which can be used to sort data into k clusters.
% Before this script can be used the following functions must be
% implemented: SelectKRandomPoints, GetRGBValuesForPoints, KMeansRGB and
% CreateKColourImage
% 
% Author: Anhad Paul

% Read in an image to convert
% If enter is hit, the image to read will default to clocktower.jpg
disp('To use your own image, add it to file and call it in the following input (ensure appropriate file size)')
disp(' ')
disp('or use the default image already in the file')
disp(' ')
imageName = input('Please enter the name of the image you which to convert, or PRESS ENTER TO USE DEFAULT IMAGE:','s');
if length(imageName) == 0
    imageName = 'clocktower.jpg';
end
A = imread(imageName);

% get the number of colours and maximum number of iterations from the user
disp(' ')
disp('Note: Approx Runtimes for number of colours using Default Image: ')
disp('3 colours (SUGGESTED): 42 seconds')
disp('4 colours: 5 minutes 4 seconds ')
disp('5 colours: >5 minutes')
disp(' ')
k = input('How many colours do you want to use? (enter a small number greater than 2):');
maxIterations = input('What is the maximum number of iterations you want to permit? (e.g. 300):');
disp('PLEASE WAIT WHILE K COLOUR VERSION OF IMAGE AND COLOUR SPACE DATA IS LOADING');
% display the original image in figure 1
figure('Name','Original Image (Not K Colour Version)','NumberTitle','off')
imshow(A)
title(['Original image: ' imageName]);

% convert image data to double format so we can do calculations with it
A=double(A);

% visualise 3D colour space data
figure(2)
plot3(A(:,:,1),A(:,:,2),A(:,:,3),'+b')
title(['Colour space data for ' imageName])
xlabel('red'); ylabel('green'); zlabel('blue');
axis tight
grid on

% select k points at random from the image
[points] = SelectKRandomPoints(A,k);

% use selected points to get the colour values for our seed means 
seedMeans = GetRGBValuesForPoints(A,points);

% use the k means algorithm to segment all pixels in the image
% into one of k clusters and calculate the corresponding means
[clusters, means] = KMeansRGB(A,seedMeans,maxIterations);

% convert the cluster data into an image by using the corresponding colour
% for each cluster (i.e. the mean colour for that cluster)
% the output will be an unsigned 8 bit integer array
B = CreateKColourImage(clusters,means);

% display the resulting k colour image and write it to a file
figure(3)
imshow(B);
title([num2str(k) ' colour version of ' imageName ])
imwrite(B,[num2str(k) 'colour' imageName]);

disp('Try seeing the output of science.jpg, a second default image already in the file.')
disp('Enter in science.jpg when prompted to on your next implementation')
