%This function assigns each pixel of the image to a cluster, based on which
%mean that point is closest to

%Inputs: 1. A 3D array of the chosen rgb image
%        2. The array of means previously created with k rows, 1 column and
%          3 layers containing the colour information for each of the means

%Outputs: A 2D array with m rows and n columns that contains the
%         corresponding cluster number for each pixel in the image.

%Author: Anhad Paul

function [clusters] = AssignToClusters(imageArray,seedMeans)

%finds the number of rows and column for chosen image
[rows,columns,colours] = size(imageArray);

squares = zeros(length(seedMeans),1); %preallocation for speed
clusters = zeros(rows,columns); %preallocation for speed

%a nested for loop cycling through the chosen images rows and columns
%while also cycling through each of the means responsible for the
%clustering
for i = 1:rows
    for j = 1:columns
        for k = 1:length(seedMeans)
            
            %'reshape' changes the output of the rgb colours from a 1x1x3 array
            %to a 1x3 array
            image_colour_row = reshape(imageArray(i,j,:),[1 3]);
            %gets the rgb colours of them means which are already
            %outputted as a 1x3 array
            k_colour_row = seedMeans(k,:);
            
            square = SquaredDistance(image_colour_row,k_colour_row);
            
            %adds the square of each pixel and mean's colours into a
            %1xk array
            squares(k) = square;
            
        end
        
        %finds the smallest square value in the 'squares' array and
        %assigns it a cluster value based on its position in the
        %squares array. i.e output of find function = 2 means cluster 2
        minsquare = min(squares);
        cluster = find(squares == minsquare);
        
        %conditional used in the event of a tie. The smallest cluster
        %value must be assigned and will always be the first value in
        %the cluster array
        if length(cluster) > 1
            cluster = cluster(1);
        end
        
        %adds the cluster values to a seperate array with its
        %corresponding pixel position
        clusters(i,j) = cluster;
        
        %resets/clears the squares array for new values to be entered
        %for the next pixel
        squares = [];
    end
end

end