%This function partitions the points in an image into k clusters, using the
%k-means algorithm to do so.

%Inputs: 1.) A 3D array of the chosen rgb image
%        2.)A 3D array contaioning the seedmeans to initialise the k means
%        algorithm
%        3.)Maximum number of iterations to perform to prevent infinite
%        looping

%Outputs: 1.)A 2D array with m rows and n columns that contains the
%          cluster number for each pixel in the image after convergence (if
%          not converged, the last calculated clusters)
%         2.) A 3D array with k rows, 1 column and 3 layers containing the
%             mean rgb values for each cluster after convergence (if
%             not converged, the last calculated clusters)

%Author: Anhad Paul

function [clusters,means] = KMeansRGB(imageArray,seedMeans,maxIterations)

means = seedMeans; %initialising mean input of AssignToClusters
NumOfMeans = length(seedMeans); %creating mean input for UpdateMeans
meanarray = {}; %initialising the cell array storing mean arrays

%sets up cycle of Assignment of Clusters and Updating means till
%convergence occurs or till the maximum iterations are reached

for i = 1:maxIterations
    
    meanarray{i} = means;
    
    clusters = AssignToClusters(imageArray,means);
    newMeans = UpdateMeans(imageArray,NumOfMeans,clusters);
    
    %using the updated means in the next cycle of AssignToClusters
    means = newMeans;
    %adding updated mean array to next value in cell array for later
    %comparison with the previous mean array
    meanarray{i+1} = means;
    
    %early return of outputs if the previous means = updatedm means
    if meanarray{i} == meanarray{i+1}
        return
    end
    
end

convergence = 0;

%if the condition above has not been met, convergence = 0 will remain
%meaning the maximum iterations was reached before convergence
if convergence == 0
    sprintf('Maximum number of iterations reached before convergence was achieved')
end


end
