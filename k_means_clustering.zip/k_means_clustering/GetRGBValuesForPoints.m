%Returns the RGB colour values for a list of specified points from an image

%Inputs: 1.A 3D image array to get RGB values from
%        2.The random pixel points array created in the previous
%           SelectKRandomPoints function.

%Outputs: 1. A 3D array with the same number of rows as the output of the
%         SelectKRandomPoints function, 1 column and 3 layers. Each row in
%         the 3D array corresponds to its matching row in the previous 2D
%         array of random points.

%Author: Anhad Paul


function [seedMeans] = GetRGBValuesForPoints(imageArray,points)

seedMeans = zeros(length(points),1,3); %preallocation for speed
for i = 1:(length(points))
    for k = 1:3
        randpixelrow = points(i,1); %getting the random row value
        randpixelcolumn = points(i,2); %getting the random column value
        
        %finding the intensity of red,green or blue (depending on k) in
        %the particular random pixel
        colour = imageArray(randpixelrow,randpixelcolumn,k);
        
        %storing the colour of the particular layer into a 3D array
        %with 3 layers
        seedMeans(i,1,k) = colour;
    end
end


