%This function calculates the mean values for each cluster

%Inputs: 1. A 3D array of the chosen rgb image
%        2. A single value k specifying how many clusters there are
%        3. A 2D array with m rows and n columns specifying which cluster
%           each pixel belongs to

%Outputs: 1. A 3D array with k rows, 1 column and 3 layers containing the
%           mean rgb values for each cluster. i.e row 1 has mean rgb values
%           for cluster 1, row 2 has mean rgb values for cluster 2....

%Author: Anhad Paul

function [means] = UpdateMeans(imageArray,NumOfMeans,clusters)

means = zeros(NumOfMeans,1,3); %preallocation for speed

for cluster = 1:NumOfMeans %cycling through the cluster numbers
    for k = 1:3 %cycling through colours/layers
        
        %findng which pixels have the specified cluster and their
        %position
        clustpos = find(clusters == cluster);
        
        %defining the particular layer we wish to extract colour values from
        imagelayer = imageArray(:,:,k);
        
        %extracting all colour values from the k layer belonging to the
        %specified cluster
        
        colour_values = imagelayer(clustpos);
        %mean calculation for the extracted values and storage into the
        %clusterx1xk 3D array
        means(cluster,1,k) = sum(colour_values)/length(colour_values);
        
    end
end
end