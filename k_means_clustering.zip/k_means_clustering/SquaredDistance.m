%This function finds the square of the the distance between two points in
%3D space.

%Inputs: 1. One point in 3D space described using either a 1x3 or 1x1x3 array
%        2. Another point in 3D space descrbed using either 1x3 or 1x1x3 array

%Outputs: 1. The square of the distance between the two points

%Author: Anhad Paul


function square = SquaredDistance(P,Q)

%converts input variables into same format.
p = double(P);
q = double(Q);

%an array of values containing the square of the difference of p and q
squaredarray = (p - q).^2;


square = sum(squaredarray);

end
